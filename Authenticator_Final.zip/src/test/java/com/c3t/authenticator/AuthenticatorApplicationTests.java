package com.c3t.authenticator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
